<?php
include 'database.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Signature</title>
</head>
<body>
<h1>Thank you for signing Up to day </h1>


<SCRIPT LANGUAGE="JavaScript">
var maintenant=new Date();
document.write(maintenant);
</SCRIPT>
<br>


<br>
<br>
<div>
<button type="button" class="btn btn-primary btn-lg"><a href="index.php">OK</a></button>

</div><br>

<div>
<button type="button" class="btn btn-primary btn-lg"><a href="profil.php">prof's</a></button>

</div




<?php
    
      // le script qui permet de signer une fois
      
       $email = $_SESSION["email"];
    $dup = mysqli_query($conn,"select id from student where email = '$email'");
      $row = mysqli_fetch_assoc($dup);
      $id = $row["id"];

    $date = date("Y-m-d");
                                   
    $verif = mysqli_query($conn,"SELECT iduser,datesign, statut FROM attendance WHERE iduser='$id' AND datesign='$date'");   
    // var_dump($verif);
    // var_dump(mysqli_num_rows($verif));
    
    if(mysqli_num_rows($verif)==1){
      
             $insertion = "UPDATE `attendance` SET `statut`='present' WHERE `iduser`= '$id'";
	  mysqli_query($conn, $insertion);
    }
    else{
        echo "vous avez déja signé";
    }
    

 ?>





  
 
      
      
