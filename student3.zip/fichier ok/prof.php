
 <?php

include 'database.php';
session_start();
$req = "SELECT student.name, COUNT('attendance.datesign'), attendance.time FROM attendance, student WHERE student.id = attendance.iduser GROUP BY name";


 if($result=$conn->query($req)){
$dataPoints = array();
$graph = array();
while($row=$result->fetch_row()){
  array_push($graph,array("y" => $row[1], "label" => "$row[0]"));

}
 }


$dataPoints = $graph;

 
?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="style.css">

<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light5",
	title:{
		text: "Student attendance"
	},
	axisY: {
		title: "signatures (par jour)"
	},
	data: [{
		type: "column",
		yValueFormatString: "#,##0.## signatures",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
</head>
<body class="container bg-light">
<br>
<br>
<br>
   

    
    </div>
<div class="row bg-secondary text-light">
  <div class="col-3 p-2"><h2><?php echo $_SESSION["name"]; ?></h2></div>
  <div class="col p-2"></div>
  <div class="col-1 p-1 d-flex flex-reverse "></div>
  <div class="col-2 p-2 d-flex flex-reverse text-light"><button type="button" class="btn btn-primary btn-lg"><a href="editprofil.php" class="text-light"></a></button><br/></div>


</div>
   
      <span>
    <a href="darshbord.php" class="text-info">Home</a>
    </span> <br>


<br><br>
<br><br>



<div class="col-10" id="chartContainer" style="height: 370px; width: 100%;"></div>


<br><br>
<br><br>
<?php

       		$sql = "SELECT student.name, attendance.datesign, attendance.time
FROM attendance, student
WHERE student.id = attendance.iduser GROUP BY name";
	$result = mysqli_query($conn,$sql);
?>
<?php if(!empty($result))	 { ?>
<table class="table-content">
          <thead>
        <tr>
                      
          <th width="30%"><span>Name</span></th>
          <th width="50%"><span>date</span></th>          
          <th width="20%"><span>time</span></th>	  
        </tr>
      </thead>
    <tbody>
	<?php
		while($row = mysqli_fetch_array($result)) {
	?>
        <tr>
			<td><?php echo $row["name"]; ?></td>
			<td><?php echo $row["datesign"]; ?></td>
			<td><?php echo $row["time"]; ?></td>

		</tr>
   <?php
		}
   ?>
   <tbody>
  </table>
<?php } ?>
  
  <br><br>


<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>



